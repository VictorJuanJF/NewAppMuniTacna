package com.example.jimenez.appmunitacna;

interface onItemClickListener {
    void onItemClick(Categoria categoria);
    void onLongItemClick(Categoria categoria);
}
