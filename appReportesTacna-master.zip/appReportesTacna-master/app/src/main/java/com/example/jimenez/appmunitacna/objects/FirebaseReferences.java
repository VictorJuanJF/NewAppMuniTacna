package com.example.jimenez.appmunitacna.objects;

public class FirebaseReferences {
    final public static String USERS_REFERENCE="user";
    final public static String CATEGORIAS_REFERENCE="categorias";
    final public static String REPORTES_REFERENCE="reportes";
    final public static String IMAGENES_REPORTES_REFERENCE="imagenesReportes";
    public static final String IMAGEN_REPORTE_FINAL_REFERENCE = "imagenBrus322";
}
